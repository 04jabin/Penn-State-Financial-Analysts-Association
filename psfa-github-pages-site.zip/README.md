# Penn State Finance & Analytics (PSFA) — Website

A minimal, fast, and accessible website for the PSFA club, designed for **GitHub Pages**.

## Quick Start (GitHub Pages)

1. Create a new repo (e.g., `psfa-club.github.io`) and upload these files.
2. In the repo settings, enable GitHub Pages (if not auto-enabled).
3. (Optional) Add a custom domain in **Pages** settings.
4. Edit `data/*.json` to update team, events, posts, and portfolio.
5. Replace placeholders: Google Form link, calendar embed, contact email, social links, meeting details.

> This site is **static** (no build step). The `.nojekyll` file disables Jekyll so JSON/asset paths serve as-is.

## Structure

```
/
├─ index.html               # Main page with sections
├─ assets/
│  ├─ css/style.css         # Minimal styling
│  └─ js/main.js            # Loads JSON and renders sections
├─ data/
│  ├─ team.json             # Leadership & members
│  ├─ events.json           # Upcoming events (ISO timestamps)
│  ├─ portfolio.json        # Mock holdings for the dashboard
│  └─ posts.json            # Blog/news items
├─ images/                  # Optional images (e.g., headshots, logos)
├─ .nojekyll                # Serve as raw static site
└─ README.md
```

## Customize

- **Club name & mission:** Edit `<title>` and About section in `index.html`.
- **Leaders:** Update `data/team.json` (name, role, bio, LinkedIn, photo).
- **Events:** Edit `data/events.json`. Or use the built-in Google Calendar embed.
- **Portfolio:** Update `data/portfolio.json` (tickers, weights, thesis). Chart renders automatically with Chart.js CDN.
- **Blog:** Add items to `data/posts.json` or link to external articles.
- **Apply:** Replace the Google Form link in the header and Hero.
- **Contact:** Update email and social links in the Contact section.
- **Partners:** Adjust the links in the Partners section.

## Notes

- **Accessibility:** High-contrast colors, semantic HTML, alt text, and responsive layout included.
- **Performance:** Single CSS & JS file, optimized DOM updates, no heavy frameworks.
- **No backend:** For forms, use Google Forms (linked) or a service like Formspree.

---

Built with ❤️ for the PSFA team.
