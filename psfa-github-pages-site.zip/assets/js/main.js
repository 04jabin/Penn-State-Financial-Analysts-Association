// Minimal client-side rendering for PSFA site
document.addEventListener('DOMContentLoaded', async () => {
  // Year in footer
  document.getElementById('year').textContent = new Date().getFullYear();

  // Load and render team
  try {
    const team = await (await fetch('data/team.json')).json();
    const grid = document.getElementById('team-grid');
    team.forEach(member => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <div class="profile">
          <img src="${member.photo || 'images/profile-placeholder.png'}" alt="${member.name} headshot">
          <div>
            <strong>${member.name}</strong><br/>
            <span class="muted">${member.role}${member.major ? ' • ' + member.major : ''}${member.year ? ' • ' + member.year : ''}</span><br/>
            ${member.linkedin ? `<a href="${member.linkedin}" target="_blank" rel="noopener">LinkedIn</a>` : ''}
          </div>
        </div>
        ${member.bio ? `<p style="margin-top:10px">${member.bio}</p>` : ''}
      `;
      grid.appendChild(card);
    });
  } catch(e) {
    console.error('Team load failed', e);
  }

  // Load and render events
  try {
    const events = await (await fetch('data/events.json')).json();
    const list = document.getElementById('events-list');
    events.sort((a,b) => new Date(a.start) - new Date(b.start));
    const upcoming = events.filter(ev => new Date(ev.end || ev.start) >= new Date()).slice(0, 6);
    (upcoming.length ? upcoming : events.slice(0, 6)).forEach(ev => {
      const item = document.createElement('div');
      item.className = 'card';
      const date = new Date(ev.start);
      const end = ev.end ? new Date(ev.end) : null;
      const dateStr = date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
      const endStr = end ? end.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : '';
      item.innerHTML = `
        <h3>${ev.title}</h3>
        <div class="muted">${dateStr}${endStr ? ' – ' + endStr : ''}${ev.location ? ' • ' + ev.location : ''}</div>
        ${ev.description ? `<p>${ev.description}</p>` : ''}
      `;
      list.appendChild(item);
    });
  } catch(e) {
    console.error('Events load failed', e);
  }

  // Load and render portfolio
  let weights = [];
  let labels = [];
  try {
    const portfolio = await (await fetch('data/portfolio.json')).json();
    const tbody = document.getElementById('portfolio-body');
    let sum = 0;
    portfolio.holdings.forEach(h => { sum += h.weight });
    portfolio.holdings.forEach(h => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${h.ticker}</td>
        <td>${h.name}</td>
        <td>${(h.weight).toFixed(1)}%</td>
        <td>${h.thesis || ''}</td>
      `;
      tbody.appendChild(tr);
      labels.push(h.ticker);
      weights.push(h.weight);
    });
    // Chart
    const ctx = document.getElementById('allocChart');
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: weights,
          hoverOffset: 6
        }]
      },
      options: {
        plugins: {
          legend: { position: 'bottom' },
          tooltip: { callbacks: { label: (ctx) => `${ctx.label}: ${ctx.parsed}%` } }
        }
      }
    });
  } catch(e) {
    console.error('Portfolio load failed', e);
  }

  // Load and render posts
  try {
    const posts = await (await fetch('data/posts.json')).json();
    const grid = document.getElementById('posts-grid');
    posts.sort((a,b) => new Date(b.date) - new Date(a.date));
    posts.slice(0,6).forEach(p => {
      const card = document.createElement('div');
      card.className = 'card';
      const dateStr = new Date(p.date).toLocaleDateString([], { dateStyle: 'medium' });
      card.innerHTML = `
        <div class="muted">${dateStr}</div>
        <h3>${p.title}</h3>
        <p>${p.summary}</p>
        ${p.link ? `<p><a href="${p.link}" target="_blank" rel="noopener">Read more →</a></p>` : ''}
      `;
      grid.appendChild(card);
    });
  } catch(e) {
    console.error('Posts load failed', e);
  }
});
